const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fs = require('fs').promises;
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

// Middleware
app.use(cors({
    origin: ['http://localhost:3000', 'http://127.0.0.1:3000'],
    credentials: true
}));
app.use(bodyParser.json({ limit: '10mb' }));
app.use(express.static('public'));

// Database file paths
const USERS_FILE = path.join(__dirname, 'data', 'users.json');
const PRODUCTS_FILE = path.join(__dirname, 'data', 'products.json');
const ORDERS_FILE = path.join(__dirname, 'data', 'orders.json');

// Helper functions
async function readData(filePath) {
    try {
        const data = await fs.readFile(filePath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error(`Error reading file ${filePath}:`, error);
        // Create empty data structure if file doesn't exist
        if (error.code === 'ENOENT') {
            const emptyData = {
                users: [],
                products: [],
                orders: []
            };
            await writeData(filePath, emptyData);
            return emptyData;
        }
        throw error;
    }
}

async function writeData(filePath, data) {
    try {
        // Ensure directory exists
        await fs.mkdir(path.dirname(filePath), { recursive: true });
        await fs.writeFile(filePath, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error(`Error writing to file ${filePath}:`, error);
        throw error;
    }
}

// Input validation middleware
const validateRegisterInput = (req, res, next) => {
    const { name, email, password, phone } = req.body;

    if (!name || !email || !password || !phone) {
        return res.status(400).json({ message: 'All fields are required' });
    }

    if (password.length < 8) {
        return res.status(400).json({ message: 'Password must be at least 8 characters long' });
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        return res.status(400).json({ message: 'Invalid email format' });
    }

    next();
};

// Authentication middleware
const authenticateToken = (req, res, next) => {
    try {
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1];

        if (!token) {
            return res.status(401).json({ message: 'Access denied. No token provided.' });
        }

        jwt.verify(token, JWT_SECRET, (err, user) => {
            if (err) {
                return res.status(403).json({ message: 'Invalid or expired token.' });
            }
            req.user = user;
            next();
        });
    } catch (error) {
        res.status(500).json({ message: 'Authentication error' });
    }
};

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ message: 'Something went wrong!' });
});

// Routes

// User Authentication
app.post('/api/register', validateRegisterInput, async(req, res) => {
    try {
        const { name, email, password, phone } = req.body;
        const data = await readData(USERS_FILE);

        // Check if user already exists
        if (data.users.some(user => user.email === email)) {
            return res.status(400).json({ message: 'Email already registered' });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create new user
        const newUser = {
            id: data.users.length + 1,
            name,
            email,
            password: hashedPassword,
            phone,
            role: 'customer',
            created_at: new Date().toISOString()
        };

        data.users.push(newUser);
        await writeData(USERS_FILE, data);

        res.status(201).json({
            message: 'Registration successful',
            user: {
                id: newUser.id,
                name: newUser.name,
                email: newUser.email,
                role: newUser.role
            }
        });
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ message: 'Error during registration' });
    }
});

app.post('/api/login', async(req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ message: 'Email and password are required' });
        }

        const data = await readData(USERS_FILE);
        const user = data.users.find(user => user.email === email);

        if (!user) {
            return res.status(401).json({ message: 'Invalid email or password' });
        }

        const validPassword = await bcrypt.compare(password, user.password);
        if (!validPassword) {
            return res.status(401).json({ message: 'Invalid email or password' });
        }

        // Create token
        const token = jwt.sign({
                id: user.id,
                email: user.email,
                role: user.role
            },
            JWT_SECRET, { expiresIn: '24h' }
        );

        res.json({
            token,
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                role: user.role
            }
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ message: 'Error during login' });
    }
});

// Products
app.get('/api/products', async(req, res) => {
    try {
        const data = await readData(PRODUCTS_FILE);
        res.json(data.products || []);
    } catch (error) {
        console.error('Products fetch error:', error);
        res.status(500).json({ message: 'Error fetching products' });
    }
});

app.get('/api/products/:id', async(req, res) => {
    try {
        const productId = parseInt(req.params.id);
        if (isNaN(productId)) {
            return res.status(400).json({ message: 'Invalid product ID' });
        }

        const data = await readData(PRODUCTS_FILE);
        const product = data.products.find(p => p.id === productId);

        if (!product) {
            return res.status(404).json({ message: 'Product not found' });
        }

        res.json(product);
    } catch (error) {
        console.error('Product fetch error:', error);
        res.status(500).json({ message: 'Error fetching product' });
    }
});

// Orders
app.post('/api/orders', authenticateToken, async(req, res) => {
    try {
        const { items, total, shippingAddress } = req.body;

        // Validate order data
        if (!items || !Array.isArray(items) || items.length === 0) {
            return res.status(400).json({ message: 'Invalid order items' });
        }

        if (!total || typeof total !== 'number' || total <= 0) {
            return res.status(400).json({ message: 'Invalid order total' });
        }

        if (!shippingAddress || typeof shippingAddress !== 'object') {
            return res.status(400).json({ message: 'Invalid shipping address' });
        }

        const data = await readData(ORDERS_FILE);

        const newOrder = {
            id: data.orders.length + 1,
            userId: req.user.id,
            items,
            total,
            shippingAddress,
            status: 'pending',
            created_at: new Date().toISOString()
        };

        data.orders.push(newOrder);
        await writeData(ORDERS_FILE, data);

        res.status(201).json(newOrder);
    } catch (error) {
        console.error('Order creation error:', error);
        res.status(500).json({ message: 'Error creating order' });
    }
});

app.get('/api/orders', authenticateToken, async(req, res) => {
    try {
        const data = await readData(ORDERS_FILE);
        const userOrders = data.orders.filter(order => order.userId === req.user.id);
        res.json(userOrders);
    } catch (error) {
        console.error('Orders fetch error:', error);
        res.status(500).json({ message: 'Error fetching orders' });
    }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Health check available at http://localhost:${PORT}/api/health`);
});