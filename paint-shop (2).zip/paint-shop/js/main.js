// Performance optimizations
// Use localStorage to cache cart data for faster loading
let cart = JSON.parse(localStorage.getItem('paintShopCart')) || [];
let wishlist = JSON.parse(localStorage.getItem('paintShopWishlist')) || [];
let currentUser = null;

// Dark mode functionality
function initDarkMode() {
    const darkModeToggle = document.getElementById('dark-mode-toggle');

    if (darkModeToggle) {
        // Check for saved dark mode preference
        if (localStorage.getItem('darkMode') === 'enabled') {
            document.body.classList.add('dark-mode');
        }

        darkModeToggle.addEventListener('click', function() {
            document.body.classList.toggle('dark-mode');

            // Save preference to localStorage
            if (document.body.classList.contains('dark-mode')) {
                localStorage.setItem('darkMode', 'enabled');
            } else {
                localStorage.setItem('darkMode', 'disabled');
            }
        });
    }
}

// Wishlist functionality
function initWishlist() {
    // Add event listeners to wishlist buttons
    const wishlistButtons = document.querySelectorAll('.wishlist-btn');

    wishlistButtons.forEach(button => {
        const productId = button.getAttribute('data-id');

        // Check if product is in wishlist and update button appearance
        if (wishlist.includes(productId)) {
            button.classList.add('in-wishlist');
            button.querySelector('i').classList.remove('far');
            button.querySelector('i').classList.add('fas');
        }

        button.addEventListener('click', function(e) {
            e.preventDefault();

            const productId = this.getAttribute('data-id');
            const productName = this.getAttribute('data-name');

            // Toggle wishlist status
            if (wishlist.includes(productId)) {
                // Remove from wishlist
                wishlist = wishlist.filter(id => id !== productId);
                this.classList.remove('in-wishlist');
                this.querySelector('i').classList.remove('fas');
                this.querySelector('i').classList.add('far');
                showNotification(`${productName} removed from wishlist`);
            } else {
                // Add to wishlist
                wishlist.push(productId);
                this.classList.add('in-wishlist');
                this.querySelector('i').classList.remove('far');
                this.querySelector('i').classList.add('fas');
                showNotification(`${productName} added to wishlist`);
            }

            // Save wishlist to localStorage
            localStorage.setItem('paintShopWishlist', JSON.stringify(wishlist));
        });
    });
}

// Recently viewed products
function initRecentlyViewed() {
    // Get recently viewed products from localStorage or initialize empty array
    let recentlyViewed = JSON.parse(localStorage.getItem('paintShopRecentlyViewed')) || [];

    // Add current product to recently viewed if on product page
    const productPage = document.querySelector('.product-detail');
    if (productPage) {
        const productId = productPage.getAttribute('data-id');
        const productName = productPage.getAttribute('data-name');
        const productPrice = productPage.getAttribute('data-price');
        const productImage = productPage.getAttribute('data-image');

        // Create product object
        const product = {
            id: productId,
            name: productName,
            price: productPrice,
            image: productImage
        };

        // Remove product if already in recently viewed
        recentlyViewed = recentlyViewed.filter(item => item.id !== productId);

        // Add product to beginning of array
        recentlyViewed.unshift(product);

        // Limit to 5 products
        recentlyViewed = recentlyViewed.slice(0, 5);

        // Save to localStorage
        localStorage.setItem('paintShopRecentlyViewed', JSON.stringify(recentlyViewed));
    }

    // Display recently viewed products if container exists
    const recentlyViewedContainer = document.getElementById('recently-viewed-container');
    if (recentlyViewedContainer && recentlyViewed.length > 0) {
        const recentlyViewedProducts = document.getElementById('recently-viewed-products');

        // Clear container
        recentlyViewedProducts.innerHTML = '';

        // Add products to container
        recentlyViewed.forEach(product => {
            const productElement = document.createElement('div');
            productElement.classList.add('recently-viewed-product');

            productElement.innerHTML = `
                <a href="product.html?id=${product.id}">
                    <div class="product-icon"><i class="fas fa-paint-roller"></i></div>
                    <h4>${product.name}</h4>
                    <span class="price">${product.price}</span>
                </a>
            `;

            recentlyViewedProducts.appendChild(productElement);
        });

        // Show container
        recentlyViewedContainer.style.display = 'block';
    }
}

// Show notification
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// Preload critical pages
function prefetchPage(url) {
    const link = document.createElement('link');
    link.rel = 'prefetch';
    link.href = url;
    document.head.appendChild(link);
}

// Optimize Shop Now button performance
function optimizeShopNowButton() {
    const shopNowBtn = document.getElementById('shop-now-btn');

    if (shopNowBtn) {
        // Preload the products page when user hovers over the button
        shopNowBtn.addEventListener('mouseenter', function() {
            prefetchPage('products.html');
        });

        // Optimize click response time
        shopNowBtn.addEventListener('click', function(e) {
            e.preventDefault();

            // Show visual feedback immediately
            this.classList.add('btn-clicked');

            // Cache the products page for faster future visits
            if ('caches' in window) {
                caches.open('paint-shop-cache').then(function(cache) {
                    cache.add('products.html');
                });
            }

            // Navigate after providing visual feedback
            setTimeout(function() {
                window.location.href = 'products.html';
            }, 50);
        });
    }
}

// API Configuration
const API_URL = 'http://localhost:3000/api';

// Sample product data (since we don't have a real API)
const sampleProducts = [{
        id: 1,
        name: "Premium Interior Paint",
        category: "interior",
        image: "https://via.placeholder.com/400x300",
        description: "High-quality paint for beautiful interior walls",
        price: 29.99,
        originalPrice: 34.99,
        rating: 4.8,
        reviewCount: 124,
        badge: "bestseller",
        isNew: false,
        isSale: true,
        discount: 15
    },
    {
        id: 2,
        name: "Weather Shield Exterior Paint",
        category: "exterior",
        image: "https://via.placeholder.com/400x300",
        description: "Long-lasting protection for exterior surfaces",
        price: 39.99,
        originalPrice: 39.99,
        rating: 4.6,
        reviewCount: 98,
        badge: null,
        isNew: false,
        isSale: false,
        discount: 0
    },
    {
        id: 3,
        name: "Wood Stain & Sealer",
        category: "specialty",
        image: "https://via.placeholder.com/400x300",
        description: "Enhances and protects wooden surfaces",
        price: 24.99,
        originalPrice: 29.99,
        rating: 4.5,
        reviewCount: 76,
        badge: null,
        isNew: false,
        isSale: true,
        discount: 17
    },
    {
        id: 4,
        name: "Professional Paint Brush Set",
        category: "tools",
        image: "https://via.placeholder.com/400x300",
        description: "Set of 5 premium brushes for all applications",
        price: 18.99,
        originalPrice: 18.99,
        rating: 4.9,
        reviewCount: 215,
        badge: "bestseller",
        isNew: false,
        isSale: false,
        discount: 0
    },
    {
        id: 5,
        name: "Eco-Friendly Interior Paint",
        category: "interior",
        image: "https://via.placeholder.com/400x300",
        description: "Low VOC formula for healthier indoor air",
        price: 32.99,
        originalPrice: 32.99,
        rating: 4.7,
        reviewCount: 89,
        badge: null,
        isNew: true,
        isSale: false,
        discount: 0
    },
    {
        id: 6,
        name: "Quick-Dry Ceiling Paint",
        category: "interior",
        image: "https://via.placeholder.com/400x300",
        description: "Specially formulated for ceiling applications",
        price: 27.99,
        originalPrice: 27.99,
        rating: 4.4,
        reviewCount: 62,
        badge: null,
        isNew: false,
        isSale: false,
        discount: 0
    },
    {
        id: 7,
        name: "Heavy-Duty Exterior Paint",
        category: "exterior",
        image: "https://via.placeholder.com/400x300",
        description: "Maximum durability for harsh weather conditions",
        price: 44.99,
        originalPrice: 54.99,
        rating: 4.8,
        reviewCount: 107,
        badge: null,
        isNew: false,
        isSale: true,
        discount: 18
    },
    {
        id: 8,
        name: "Professional Roller Set",
        category: "tools",
        image: "https://via.placeholder.com/400x300",
        description: "Complete set with tray and multiple roller sizes",
        price: 22.99,
        originalPrice: 22.99,
        rating: 4.6,
        reviewCount: 83,
        badge: null,
        isNew: true,
        isSale: false,
        discount: 0
    },
    {
        id: 9,
        name: "Concrete & Masonry Paint",
        category: "specialty",
        image: "https://via.placeholder.com/400x300",
        description: "Specifically designed for concrete surfaces",
        price: 36.99,
        originalPrice: 36.99,
        rating: 4.5,
        reviewCount: 54,
        badge: null,
        isNew: false,
        isSale: false,
        discount: 0
    },
    {
        id: 10,
        name: "Premium Painter's Tape",
        category: "tools",
        image: "https://via.placeholder.com/400x300",
        description: "Clean removal with no residue",
        price: 8.99,
        originalPrice: 10.99,
        rating: 4.7,
        reviewCount: 192,
        badge: "bestseller",
        isNew: false,
        isSale: true,
        discount: 18
    },
    {
        id: 11,
        name: "Anti-Mold Bathroom Paint",
        category: "specialty",
        image: "https://via.placeholder.com/400x300",
        description: "Prevents mold and mildew in high-humidity areas",
        price: 38.99,
        originalPrice: 38.99,
        rating: 4.8,
        reviewCount: 76,
        badge: null,
        isNew: true,
        isSale: false,
        discount: 0
    },
    {
        id: 12,
        name: "Trim & Cabinet Enamel",
        category: "interior",
        image: "https://via.placeholder.com/400x300",
        description: "Smooth, durable finish for trim and cabinets",
        price: 33.99,
        originalPrice: 39.99,
        rating: 4.6,
        reviewCount: 68,
        badge: null,
        isNew: false,
        isSale: true,
        discount: 15
    }
]

// Authentication functions
async function register(userData) {
    try {
        const response = await fetch(`${API_URL}/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(userData)
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.message);
        }

        showNotification('Registration successful! Please login.', 'success');
        return true;
    } catch (error) {
        showNotification(error.message, 'error');
        return false;
    }
}

async function login(email, password) {
    try {
        const response = await fetch(`${API_URL}/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.message);
        }

        // Store token and user data
        localStorage.setItem('token', data.token);
        localStorage.setItem('currentUser', JSON.stringify(data.user));
        currentUser = data.user;

        showNotification('Login successful!', 'success');
        return true;
    } catch (error) {
        showNotification(error.message, 'error');
        return false;
    }
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('currentUser');
    currentUser = null;
    showNotification('Logged out successfully', 'success');
}

function isLoggedIn() {
    return currentUser !== null;
}

function initializeUserSession() {
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
        currentUser = JSON.parse(storedUser);
    }
}

// Global variables for product management
let currentProducts = [];
let currentPage = 1;
let productsPerPage = 6;
let currentFilters = {
    categories: ['interior', 'exterior', 'specialty', 'tools'],
    maxPrice: 100,
    minRating: 0,
    searchTerm: ''
};
let currentSort = 'popular';

// Product functions
async function loadProducts(category = null) {
    try {
        // In a real app, this would fetch from the API
        // For now, we'll use our sample data
        let filteredProducts = [...sampleProducts];

        if (category) {
            filteredProducts = filteredProducts.filter(product => product.category === category);
        }

        currentProducts = filteredProducts;
        applyFiltersAndSort();
    } catch (error) {
        console.error('Error loading products:', error);
    }
}

function applyFiltersAndSort() {
    // Apply filters
    let filtered = currentProducts.filter(product => {
        // Category filter
        if (!currentFilters.categories.includes(product.category)) {
            return false;
        }

        // Price filter
        if (product.price > currentFilters.maxPrice) {
            return false;
        }

        // Rating filter
        if (product.rating < currentFilters.minRating) {
            return false;
        }

        // Search term
        if (currentFilters.searchTerm && !product.name.toLowerCase().includes(currentFilters.searchTerm.toLowerCase()) &&
            !product.description.toLowerCase().includes(currentFilters.searchTerm.toLowerCase())) {
            return false;
        }

        return true;
    });

    // Apply sorting
    switch (currentSort) {
        case 'price-low':
            filtered.sort((a, b) => a.price - b.price);
            break;
        case 'price-high':
            filtered.sort((a, b) => b.price - a.price);
            break;
        case 'newest':
            filtered.sort((a, b) => b.id - a.id);
            break;
        case 'rating':
            filtered.sort((a, b) => b.rating - a.rating);
            break;
        case 'popular':
        default:
            filtered.sort((a, b) => b.reviewCount - a.reviewCount);
            break;
    }

    // Update pagination
    updatePagination(filtered.length);

    // Display the current page
    const startIndex = (currentPage - 1) * productsPerPage;
    const endIndex = startIndex + productsPerPage;
    const currentPageProducts = filtered.slice(startIndex, endIndex);

    displayProducts(currentPageProducts);
}

function updatePagination(totalProducts) {
    const totalPages = Math.ceil(totalProducts / productsPerPage);
    const paginationNumbers = document.querySelector('.pagination-numbers');

    if (paginationNumbers) {
        paginationNumbers.innerHTML = '';

        // Limit to show max 5 page numbers
        let startPage = Math.max(1, currentPage - 2);
        let endPage = Math.min(totalPages, startPage + 4);

        // Adjust if we're near the end
        if (endPage - startPage < 4 && startPage > 1) {
            startPage = Math.max(1, endPage - 4);
        }

        for (let i = startPage; i <= endPage; i++) {
            const pageButton = document.createElement('button');
            pageButton.className = `pagination-number${i === currentPage ? ' active' : ''}`;
            pageButton.textContent = i;
            pageButton.addEventListener('click', () => {
                currentPage = i;
                applyFiltersAndSort();

                // Update active state
                document.querySelectorAll('.pagination-number').forEach(btn => {
                    btn.classList.remove('active');
                });
                pageButton.classList.add('active');
            });

            paginationNumbers.appendChild(pageButton);
        }
    }

    // Update prev/next buttons
    const prevBtn = document.querySelector('.pagination-btn[data-page="prev"]');
    const nextBtn = document.querySelector('.pagination-btn[data-page="next"]');

    if (prevBtn) {
        prevBtn.disabled = currentPage === 1;
    }

    if (nextBtn) {
        nextBtn.disabled = currentPage === totalPages;
    }
}

function displayProducts(products) {
    const productGrid = document.getElementById('product-grid');
    if (!productGrid) return;

    productGrid.innerHTML = '';

    if (products.length === 0) {
        productGrid.innerHTML = `
            <div class="no-products">
                <i class="fas fa-search"></i>
                <h3>No products found</h3>
                <p>Try adjusting your filters or search term</p>
            </div>
        `;
        return;
    }

    products.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'product-card';

        // Generate star rating HTML
        const fullStars = Math.floor(product.rating);
        const hasHalfStar = product.rating % 1 >= 0.5;
        let starsHTML = '';

        for (let i = 0; i < 5; i++) {
            if (i < fullStars) {
                starsHTML += '<i class="fas fa-star"></i>';
            } else if (i === fullStars && hasHalfStar) {
                starsHTML += '<i class="fas fa-star-half-alt"></i>';
            } else {
                starsHTML += '<i class="far fa-star"></i>';
            }
        }

        // Create badge HTML if needed
        let badgeHTML = '';
        if (product.isNew) {
            badgeHTML = '<span class="product-badge new">New</span>';
        } else if (product.isSale) {
            badgeHTML = `<span class="product-badge sale">Sale ${product.discount}%</span>`;
        } else if (product.badge) {
            badgeHTML = `<span class="product-badge">${product.badge}</span>`;
        }

        // Create price HTML
        let priceHTML = '';
        if (product.originalPrice > product.price) {
            priceHTML = `
                <span class="current-price">$${product.price.toFixed(2)}</span>
                <span class="original-price">$${product.originalPrice.toFixed(2)}</span>
                <span class="discount-percent">-${product.discount}%</span>
            `;
        } else {
            priceHTML = `<span class="current-price">$${product.price.toFixed(2)}</span>`;
        }

        productCard.innerHTML = `
            <div class="product-image">
                <img src="${product.image}" alt="${product.name}">
                ${badgeHTML}
                <div class="product-actions">
                    <div class="action-btn" title="Add to Wishlist">
                        <i class="far fa-heart"></i>
                    </div>
                    <div class="action-btn" title="Quick View" onclick="openQuickView(${product.id})">
                        <i class="far fa-eye"></i>
                    </div>
                    <div class="action-btn" title="Compare">
                        <i class="fas fa-exchange-alt"></i>
                    </div>
                </div>
            </div>
            <div class="product-info">
                <div class="product-category">${product.category.charAt(0).toUpperCase() + product.category.slice(1)}</div>
                <h3 class="product-title">${product.name}</h3>
                <div class="product-rating">
                    <div class="stars">${starsHTML}</div>
                    <span class="rating-count">(${product.reviewCount})</span>
                </div>
                <div class="product-price">
                    ${priceHTML}
                </div>
            </div>
            <div class="product-footer">
                <button class="add-to-cart" onclick="addToCart(${product.id})">
                    <i class="fas fa-shopping-cart"></i> Add to Cart
                </button>
                <button class="quick-view" onclick="openQuickView(${product.id})">Quick View</button>
            </div>
        `;

        productGrid.appendChild(productCard);
    });
}

function openQuickView(productId) {
    const product = sampleProducts.find(p => p.id === productId);
    if (!product) return;

    const modal = document.getElementById('quick-view-modal');
    const modalContent = modal.querySelector('.modal-product-details');

    // Generate star rating HTML
    const fullStars = Math.floor(product.rating);
    const hasHalfStar = product.rating % 1 >= 0.5;
    let starsHTML = '';

    for (let i = 0; i < 5; i++) {
        if (i < fullStars) {
            starsHTML += '<i class="fas fa-star"></i>';
        } else if (i === fullStars && hasHalfStar) {
            starsHTML += '<i class="fas fa-star-half-alt"></i>';
        } else {
            starsHTML += '<i class="far fa-star"></i>';
        }
    }

    // Create price HTML
    let priceHTML = '';
    if (product.originalPrice > product.price) {
        priceHTML = `
            <span class="current-price">$${product.price.toFixed(2)}</span>
            <span class="original-price">$${product.originalPrice.toFixed(2)}</span>
            <span class="discount-percent">-${product.discount}%</span>
        `;
    } else {
        priceHTML = `<span class="current-price">$${product.price.toFixed(2)}</span>`;
    }

    modalContent.innerHTML = `
        <div class="modal-product-image">
            <img src="${product.image}" alt="${product.name}">
        </div>
        <div class="modal-product-info">
            <h2>${product.name}</h2>
            <div class="product-rating">
                <div class="stars">${starsHTML}</div>
                <span class="rating-count">(${product.reviewCount} reviews)</span>
            </div>
            <div class="product-price">
                ${priceHTML}
            </div>
            <p class="product-description">${product.description}</p>
            <div class="product-meta">
                <div class="meta-item">
                    <span class="meta-label">Category:</span>
                    <span class="meta-value">${product.category.charAt(0).toUpperCase() + product.category.slice(1)}</span>
                </div>
                <div class="meta-item">
                    <span class="meta-label">SKU:</span>
                    <span class="meta-value">CC-${product.id.toString().padStart(4, '0')}</span>
                </div>
            </div>
            <div class="product-quantity">
                <label for="quantity">Quantity:</label>
                <div class="quantity-control">
                    <button class="quantity-btn minus">-</button>
                    <input type="number" id="quantity" value="1" min="1">
                    <button class="quantity-btn plus">+</button>
                </div>
            </div>
            <div class="modal-actions">
                <button class="add-to-cart" onclick="addToCart(${product.id})">
                    <i class="fas fa-shopping-cart"></i> Add to Cart
                </button>
                <button class="wishlist-btn">
                    <i class="far fa-heart"></i> Add to Wishlist
                </button>
            </div>
        </div>
    `;

    // Show the modal
    modal.style.display = 'flex';

    // Setup quantity controls
    const quantityInput = modalContent.querySelector('#quantity');
    const minusBtn = modalContent.querySelector('.quantity-btn.minus');
    const plusBtn = modalContent.querySelector('.quantity-btn.plus');

    minusBtn.addEventListener('click', () => {
        const currentValue = parseInt(quantityInput.value);
        if (currentValue > 1) {
            quantityInput.value = currentValue - 1;
        }
    });

    plusBtn.addEventListener('click', () => {
        const currentValue = parseInt(quantityInput.value);
        quantityInput.value = currentValue + 1;
    });

    // Setup close button
    const closeBtn = modal.querySelector('.close-modal');
    closeBtn.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    // Close when clicking outside the modal content
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });
}

// Cart functions
function addToCart(productId) {
    if (!isLoggedIn()) {
        showNotification('Please login to add items to cart', 'error');
        return;
    }

    const product = currentProducts.find(p => p.id === productId);
    if (product) {
        const existingItem = cart.find(item => item.id === productId);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({
                id: product.id,
                name: product.name,
                price: product.price,
                quantity: 1
            });
        }
        // Save cart to localStorage for persistence and faster loading
        localStorage.setItem('paintShopCart', JSON.stringify(cart));

        // Update UI
        updateCartDisplay();
        showAddToCartNotification(product.name);

        // Preload cart page when items are added
        prefetchPage('cart.html');
    }
}

function showAddToCartNotification(productName) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'cart-notification';
    notification.innerHTML = `
        <i class="fas fa-check-circle"></i>
        <p><strong>${productName}</strong> has been added to your cart</p>
    `;

    // Add to body
    document.body.appendChild(notification);

    // Show notification with animation
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);

    // Remove after 3 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

function updateCartDisplay() {
    const cartCount = document.querySelector('.cart-count');
    if (cartCount) {
        cartCount.textContent = cart.reduce((total, item) => total + item.quantity, 0);
    }
}

// Payment functions
async function processPayment(paymentDetails) {
    try {
        const response = await fetch(`${API_URL}/payment`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(paymentDetails)
        });
        const data = await response.json();
        if (data.success) {
            alert('Payment successful!');
            cart = [];
            updateCartDisplay();
        }
    } catch (error) {
        console.error('Payment error:', error);
    }
}

// Three dots menu functionality
function toggleDropdownMenu() {
    const dropdownMenu = document.querySelector('.dropdown-menu');
    dropdownMenu.classList.toggle('active');
}

// Close dropdown when clicking outside
document.addEventListener('click', (event) => {
    const menuDots = document.querySelector('.menu-dots');
    const dropdownMenu = document.querySelector('.dropdown-menu');

    if (menuDots && dropdownMenu) {
        if (!menuDots.contains(event.target) && dropdownMenu.classList.contains('active')) {
            dropdownMenu.classList.remove('active');
        }
    }
});

// Color Guide functionality
function initColorGuide() {
    const colorCategories = document.querySelectorAll('.color-category');
    const colorPalettes = document.querySelectorAll('.color-palette');

    // Color category tabs functionality
    colorCategories.forEach(category => {
        category.addEventListener('click', () => {
            // Remove active class from all categories
            colorCategories.forEach(cat => cat.classList.remove('active'));
            // Add active class to clicked category
            category.classList.add('active');

            // Hide all palettes
            colorPalettes.forEach(palette => {
                palette.classList.add('hidden');
            });

            // Show the selected palette
            const targetCategory = category.getAttribute('data-category');
            const targetPalette = document.getElementById(targetCategory);
            if (targetPalette) {
                targetPalette.classList.remove('hidden');
            }
        });
    });

    // Color picker button functionality
    const colorPickerBtn = document.getElementById('colorPicker');
    if (colorPickerBtn) {
        colorPickerBtn.addEventListener('click', () => {
            alert('Color picker tool will be available soon!');
        });
    }

    // Save palette button functionality
    const savePaletteBtn = document.getElementById('saveColors');
    if (savePaletteBtn) {
        savePaletteBtn.addEventListener('click', () => {
            alert('Your color palette has been saved!');
        });
    }
}

// Contact form functionality
function initContactForm() {
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const name = document.getElementById('name').value;
            alert(`Thank you, ${name}! Your message has been sent. We'll get back to you soon.`);
            contactForm.reset();
        });
    }
}

// Category filtering functionality
function initCategoryFilter() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const categoryCards = document.querySelectorAll('.category-card');

    if (filterButtons.length && categoryCards.length) {
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                // Remove active class from all buttons
                filterButtons.forEach(btn => btn.classList.remove('active'));

                // Add active class to clicked button
                button.classList.add('active');

                // Get the filter value
                const filterValue = button.getAttribute('data-filter');

                // Filter the category cards
                categoryCards.forEach(card => {
                    if (filterValue === 'all') {
                        card.style.display = 'flex';
                        // Add animation
                        animateCard(card);
                    } else {
                        const cardCategory = card.getAttribute('data-category');
                        if (cardCategory === filterValue) {
                            card.style.display = 'flex';
                            // Add animation
                            animateCard(card);
                        } else {
                            card.style.display = 'none';
                        }
                    }
                });
            });
        });

        // Add click event to view buttons
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation(); // Prevent the card's onclick from firing
                const categoryCard = e.target.closest('.category-card');
                if (categoryCard) {
                    const categoryName = categoryCard.querySelector('h3').textContent;
                    loadProducts(categoryName);

                    // Scroll to products section
                    document.getElementById('products').scrollIntoView({ behavior: 'smooth' });
                }
            });
        });
    }
}

// Helper function to animate cards when they appear
function animateCard(card) {
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';

    setTimeout(() => {
        card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        card.style.opacity = '1';
        card.style.transform = 'translateY(0)';
    }, 10);

    // Reset transition after animation completes
    setTimeout(() => {
        card.style.transition = 'all 0.3s ease';
    }, 500);
}

// Initialize product filters and controls
function initProductFilters() {
    // Price range slider
    const priceSlider = document.getElementById('price-range');
    const priceValue = document.getElementById('price-value');

    if (priceSlider && priceValue) {
        priceSlider.addEventListener('input', () => {
            const value = priceSlider.value;
            priceValue.textContent = `$${value}`;
            currentFilters.maxPrice = parseInt(value);
        });
    }

    // Category checkboxes
    const categoryCheckboxes = document.querySelectorAll('.filter-option input[type="checkbox"]');
    categoryCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', () => {
            // Update categories filter
            const categories = [];
            document.querySelectorAll('.filter-option input[type="checkbox"]:checked').forEach(cb => {
                categories.push(cb.value);
            });
            currentFilters.categories = categories;
        });
    });

    // Rating filters
    const ratingCheckboxes = document.querySelectorAll('.filter-group:nth-child(3) .filter-option input[type="checkbox"]');
    ratingCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', () => {
            // Find highest checked rating
            let minRating = 0;
            document.querySelectorAll('.filter-group:nth-child(3) .filter-option input[type="checkbox"]:checked').forEach(cb => {
                const rating = parseInt(cb.value);
                if (rating > minRating) {
                    minRating = rating;
                }
            });
            currentFilters.minRating = minRating;
        });
    });

    // Apply filters button
    const applyFiltersBtn = document.getElementById('apply-filters');
    if (applyFiltersBtn) {
        applyFiltersBtn.addEventListener('click', () => {
            currentPage = 1;
            applyFiltersAndSort();
        });
    }

    // Reset filters button
    const resetFiltersBtn = document.getElementById('reset-filters');
    if (resetFiltersBtn) {
        resetFiltersBtn.addEventListener('click', () => {
            // Reset checkboxes
            document.querySelectorAll('.filter-option input[type="checkbox"]').forEach(cb => {
                cb.checked = true;
            });

            // Reset price slider
            if (priceSlider && priceValue) {
                priceSlider.value = 100;
                priceValue.textContent = '$100';
            }

            // Reset filter values
            currentFilters = {
                categories: ['interior', 'exterior', 'specialty', 'tools'],
                maxPrice: 100,
                minRating: 0,
                searchTerm: ''
            };

            currentPage = 1;
            applyFiltersAndSort();
        });
    }

    // Search functionality
    const searchInput = document.getElementById('product-search');
    const searchBtn = document.querySelector('.search-btn');

    if (searchInput && searchBtn) {
        searchBtn.addEventListener('click', () => {
            currentFilters.searchTerm = searchInput.value.trim();
            currentPage = 1;
            applyFiltersAndSort();
        });

        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                currentFilters.searchTerm = searchInput.value.trim();
                currentPage = 1;
                applyFiltersAndSort();
            }
        });
    }

    // Sort functionality
    const sortSelect = document.getElementById('sort-by');
    if (sortSelect) {
        sortSelect.addEventListener('change', () => {
            currentSort = sortSelect.value;
            applyFiltersAndSort();
        });
    }

    // Pagination prev/next buttons
    const prevBtn = document.querySelector('.pagination-btn[data-page="prev"]');
    const nextBtn = document.querySelector('.pagination-btn[data-page="next"]');

    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            if (currentPage > 1) {
                currentPage--;
                applyFiltersAndSort();
            }
        });
    }

    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            const totalPages = Math.ceil(currentProducts.length / productsPerPage);
            if (currentPage < totalPages) {
                currentPage++;
                applyFiltersAndSort();
            }
        });
    }
}

// Add CSS for cart notification
function addCartNotificationStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .cart-notification {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: var(--primary-color);
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            transform: translateY(100px);
            opacity: 0;
            transition: all 0.3s ease;
            z-index: 1000;
        }
        
        .cart-notification.show {
            transform: translateY(0);
            opacity: 1;
        }
        
        .cart-notification i {
            font-size: 1.5rem;
            color: #99b898;
        }
        
        .cart-notification p {
            margin: 0;
        }
    `;
    document.head.appendChild(style);
}

// Order Details Page Functionality
function initOrderDetailsPage() {
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    if (tabButtons.length === 0) return; // Not on order details page

    // Tab switching functionality
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const tabId = button.getAttribute('data-tab');

            // Update active tab button
            tabButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            // Update active tab content
            tabContents.forEach(content => {
                content.classList.remove('active');
                if (content.id === tabId) {
                    content.classList.add('active');
                }
            });
        });
    });

    // Track order form submission
    const trackOrderForm = document.getElementById('track-order-form');
    if (trackOrderForm) {
        trackOrderForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const orderNumber = document.getElementById('order-number').value;
            const orderEmail = document.getElementById('order-email').value;

            // In a real application, this would make an API call to fetch order tracking data
            // For demo purposes, we'll just show the tracking result
            document.getElementById('tracking-order-id').textContent = orderNumber;
            document.getElementById('tracking-result').style.display = 'block';

            // Scroll to tracking result
            document.getElementById('tracking-result').scrollIntoView({ behavior: 'smooth' });
        });
    }

    // Order search functionality
    const orderSearchInput = document.getElementById('order-search-input');
    if (orderSearchInput) {
        orderSearchInput.addEventListener('input', (e) => {
            const searchTerm = e.target.value.toLowerCase();
            const orderCards = document.querySelectorAll('#active-orders .order-card');

            orderCards.forEach(card => {
                const orderNumber = card.querySelector('.order-info h3').textContent.toLowerCase();
                const productNames = Array.from(card.querySelectorAll('.item-details h4'))
                    .map(item => item.textContent.toLowerCase());

                const matchesSearch = orderNumber.includes(searchTerm) ||
                    productNames.some(name => name.includes(searchTerm));

                card.style.display = matchesSearch ? 'block' : 'none';
            });
        });
    }

    // History search functionality
    const historySearchInput = document.getElementById('history-search-input');
    if (historySearchInput) {
        historySearchInput.addEventListener('input', (e) => {
            const searchTerm = e.target.value.toLowerCase();
            const orderCards = document.querySelectorAll('#order-history .order-card');

            orderCards.forEach(card => {
                const orderNumber = card.querySelector('.order-info h3').textContent.toLowerCase();
                const productNames = Array.from(card.querySelectorAll('.item-details h4'))
                    .map(item => item.textContent.toLowerCase());

                const matchesSearch = orderNumber.includes(searchTerm) ||
                    productNames.some(name => name.includes(searchTerm));

                card.style.display = matchesSearch ? 'block' : 'none';
            });
        });
    }

    // View details button functionality
    const viewDetailsButtons = document.querySelectorAll('.order-actions .btn-primary');
    viewDetailsButtons.forEach(button => {
        button.addEventListener('click', () => {
            // In a real application, this would navigate to a detailed order page
            // For demo purposes, we'll just switch to the track order tab and populate it
            const orderCard = button.closest('.order-card');
            const orderNumber = orderCard.querySelector('.order-info h3').textContent;

            // Switch to track order tab
            tabButtons.forEach(btn => {
                if (btn.getAttribute('data-tab') === 'track-order') {
                    btn.click();
                }
            });

            // Populate the form
            document.getElementById('order-number').value = orderNumber.replace('Order #', '');

            // Submit the form
            document.getElementById('track-order-form').dispatchEvent(new Event('submit'));
        });
    });

    // Track order button functionality
    const trackOrderButtons = document.querySelectorAll('.order-actions .btn-secondary');
    trackOrderButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Similar to view details, but just switches to track order tab
            const orderCard = button.closest('.order-card');
            const orderNumber = orderCard.querySelector('.order-info h3').textContent;

            // Switch to track order tab
            tabButtons.forEach(btn => {
                if (btn.getAttribute('data-tab') === 'track-order') {
                    btn.click();
                }
            });

            // Populate the form
            document.getElementById('order-number').value = orderNumber.replace('Order #', '');
        });
    });
}

// Header functionality with performance optimizations
function initHeader() {
    const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (mobileMenuToggle && navLinks) {
        mobileMenuToggle.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            mobileMenuToggle.classList.toggle('active');
        });
    }

    // Make header sticky on scroll with performance optimization
    const header = document.querySelector('header');
    let lastScrollTop = 0;
    let scrollTimeout;

    // Use passive event listener for better scroll performance
    window.addEventListener('scroll', () => {
        // Throttle scroll events for better performance
        if (!scrollTimeout) {
            scrollTimeout = setTimeout(() => {
                const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

                if (scrollTop > 100) {
                    header.classList.add('sticky');
                    if (scrollTop > lastScrollTop) {
                        header.classList.add('hide');
                    } else {
                        header.classList.remove('hide');
                    }
                } else {
                    header.classList.remove('sticky');
                }

                lastScrollTop = scrollTop;
                scrollTimeout = null;
            }, 10);
        }
    }, { passive: true });

    // Optimize search functionality badge animation
    const cartCount = document.querySelector('.cart-count');
    if (cartCount && parseInt(cartCount.textContent) > 0) {
        setTimeout(() => {
            cartCount.classList.add('pulse');
            setTimeout(() => cartCount.classList.remove('pulse'), 1000);
        }, 2000);
    }
}

// Enhanced Navigation Functions
function initEnhancedNavigation() {
    // Mobile menu toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const mobileMenuClose = document.querySelector('.mobile-menu-close');
    const navLinks = document.querySelector('.nav-links');

    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', () => {
            navLinks.classList.add('active');
            document.body.style.overflow = 'hidden'; // Prevent scrolling when menu is open
        });
    }

    if (mobileMenuClose) {
        mobileMenuClose.addEventListener('click', () => {
            navLinks.classList.remove('active');
            document.body.style.overflow = ''; // Re-enable scrolling
        });
    }

    // Sticky navigation on scroll
    const navbar = document.querySelector('.navbar');
    let lastScrollTop = 0;

    window.addEventListener('scroll', () => {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

        if (scrollTop > 100) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }

        lastScrollTop = scrollTop;
    });

    // Mobile dropdown toggles
    const navItems = document.querySelectorAll('.nav-item');

    if (window.innerWidth < 992) {
        navItems.forEach(item => {
            const link = item.querySelector('a');

            link.addEventListener('click', (e) => {
                // Only if it has a mega menu
                if (item.querySelector('.mega-menu-container')) {
                    e.preventDefault();
                    item.classList.toggle('active');
                }
            });
        });
    }
}

// Initialize with performance optimizations
document.addEventListener('DOMContentLoaded', () => {
    // Initialize critical functionality first
    initHeader();
    optimizeShopNowButton();
    initDarkMode();
    initEnhancedNavigation();

    // Initialize enhanced features
    initWishlist();
    initRecentlyViewed();

    // Add event listeners to add-to-cart buttons
    const addToCartButtons = document.querySelectorAll('.btn-add-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.getAttribute('data-id');
            const productName = this.getAttribute('data-name');
            const productPrice = this.getAttribute('data-price');

            // Add to cart
            addToCart({
                id: productId,
                name: productName,
                price: productPrice,
                quantity: 1
            });

            // Show notification
            showNotification(`${productName} added to cart!`, 'success');
        });
    });

    // Preload important pages
    setTimeout(() => {
        prefetchPage('products.html');
        prefetchPage('cart.html');
        prefetchPage('visualizer.html');
    }, 2000); // Delay prefetching to prioritize initial page load

    // Add cart notification styles
    addCartNotificationStyles();

    // Initialize order details page if we're on that page
    initOrderDetailsPage();

    // Load products
    loadProducts();
    updateCartDisplay();

    // Set up three dots menu click handler
    const dotsIcon = document.querySelector('.dots-icon');
    if (dotsIcon) {
        dotsIcon.addEventListener('click', (e) => {
            e.stopPropagation();
            toggleDropdownMenu();
        });
    }

    // Initialize Product Filters
    initProductFilters();

    // Initialize Category Filter functionality
    initCategoryFilter();

    // Initialize Color Guide functionality
    initColorGuide();

    // Initialize Contact Form functionality
    initContactForm();

    // Add event listeners for login form if it exists
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', async(e) => {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            if (await login(email, password)) {
                window.location.href = 'index.html';
            }
        });
    }

    // Add event listeners for register form if it exists
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', async(e) => {
            e.preventDefault();

            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const phone = document.getElementById('phone').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm-password').value;

            if (password !== confirmPassword) {
                showNotification('Passwords do not match', 'error');
                return;
            }

            if (password.length < 8) {
                showNotification('Password must be at least 8 characters long', 'error');
                return;
            }

            const userData = {
                name,
                email,
                phone,
                password
            };

            if (await register(userData)) {
                window.location.href = 'login.html';
            }
        });
    }

    // Add event listener for logout button if it exists
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            logout();
            window.location.href = 'index.html';
        });
    }
});