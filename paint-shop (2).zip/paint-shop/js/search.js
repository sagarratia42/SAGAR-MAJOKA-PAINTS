// Enhanced Search Functionality

const searchData = [
    {
        id: 1,
        title: 'Premium White Paint',
        category: 'interior',
        description: 'Classic, clean finish for any space',
        price: 1299,
        icon: 'fa-paint-roller'
    },
    {
        id: 2,
        title: 'Eco-Friendly Paint',
        category: 'interior',
        description: 'Zero VOC, sustainable choice',
        price: 1599,
        icon: 'fa-leaf'
    },
    {
        id: 3,
        title: 'Exterior Weather Shield',
        category: 'exterior',
        description: 'Long-lasting protection against elements',
        price: 1899,
        icon: 'fa-tint'
    },
    {
        id: 4,
        title: 'Textured Wall Paint',
        category: 'specialty',
        description: 'Create unique wall textures',
        price: 1499,
        icon: 'fa-brush'
    },
    {
        id: 5,
        title: 'Ceiling White',
        category: 'interior',
        description: 'Bright white for ceilings',
        price: 1199,
        icon: 'fa-home'
    },
    {
        id: 6,
        title: 'Wood Stain',
        category: 'exterior',
        description: 'Enhance natural wood grain',
        price: 1699,
        icon: 'fa-tree'
    },
    {
        id: 7,
        title: 'Metal Paint',
        category: 'specialty',
        description: 'Rust prevention for metal surfaces',
        price: 1799,
        icon: 'fa-wrench'
    },
    {
        id: 8,
        title: 'Paint Roller Set',
        category: 'tools',
        description: 'Professional quality roller set',
        price: 599,
        icon: 'fa-tools'
    },
    {
        id: 9,
        title: 'Premium Brushes',
        category: 'tools',
        description: 'Set of 5 premium brushes',
        price: 799,
        icon: 'fa-paint-brush'
    },
    {
        id: 10,
        title: 'Color Matching Kit',
        category: 'tools',
        description: 'Match any color perfectly',
        price: 1299,
        icon: 'fa-palette'
    }
];

function initEnhancedSearch() {
    const searchInput = document.getElementById('search-input');
    const searchBtn = document.getElementById('search-btn');
    const voiceSearchBtn = document.getElementById('voice-search-btn');
    const searchResults = document.getElementById('search-results');
    const searchCategories = document.querySelectorAll('.search-category');
    
    // Store recent searches
    let recentSearches = JSON.parse(localStorage.getItem('recentSearches')) || [];
    
    // Function to perform search
    function performSearch(query) {
        if (!query || query.trim() === '') {
            searchResults.classList.remove('active');
            return;
        }
        
        // Filter search data based on query
        const results = searchData.filter(item => {
            return (
                item.title.toLowerCase().includes(query.toLowerCase()) ||
                item.description.toLowerCase().includes(query.toLowerCase()) ||
                item.category.toLowerCase().includes(query.toLowerCase())
            );
        });
        
        // Display results
        if (results.length > 0) {
            let resultsHTML = '';
            
            results.forEach(item => {
                resultsHTML += `
                <a href="products.html?id=${item.id}" class="search-result-item">
                    <div class="search-result-icon">
                        <i class="fas ${item.icon}"></i>
                    </div>
                    <div class="search-result-content">
                        <div class="search-result-title">${item.title}</div>
                        <div class="search-result-desc">${item.description}</div>
                    </div>
                    <div class="search-result-price">₹${item.price}</div>
                </a>
                `;
            });
            
            // Add recent searches if available
            if (recentSearches.length > 0 && query.length < 3) {
                resultsHTML += `
                <div class="recent-searches">
                    <div class="recent-searches-title">Recent Searches</div>
                    <div class="recent-search-tags">
                        ${recentSearches.map(search => `<div class="recent-search-tag">${search}</div>`).join('')}
                    </div>
                </div>
                `;
            }
            
            searchResults.innerHTML = resultsHTML;
            searchResults.classList.add('active');
            
            // Add event listeners to recent search tags
            const recentSearchTags = document.querySelectorAll('.recent-search-tag');
            recentSearchTags.forEach(tag => {
                tag.addEventListener('click', function() {
                    searchInput.value = this.textContent;
                    performSearch(this.textContent);
                });
            });
        } else {
            searchResults.innerHTML = `<div class="search-result-item">No results found for "${query}"</div>`;
            searchResults.classList.add('active');
        }
        
        // Save to recent searches if not already there
        if (query.length > 2 && !recentSearches.includes(query)) {
            recentSearches.unshift(query);
            recentSearches = recentSearches.slice(0, 5); // Keep only 5 recent searches
            localStorage.setItem('recentSearches', JSON.stringify(recentSearches));
        }
    }
    
    // Search input event listeners
    if (searchInput) {
        searchInput.addEventListener('focus', function() {
            if (this.value.trim() !== '') {
                performSearch(this.value);
            } else if (recentSearches.length > 0) {
                // Show recent searches when focused with empty input
                let resultsHTML = `
                <div class="recent-searches">
                    <div class="recent-searches-title">Recent Searches</div>
                    <div class="recent-search-tags">
                        ${recentSearches.map(search => `<div class="recent-search-tag">${search}</div>`).join('')}
                    </div>
                </div>
                `;
                searchResults.innerHTML = resultsHTML;
                searchResults.classList.add('active');
                
                // Add event listeners to recent search tags
                const recentSearchTags = document.querySelectorAll('.recent-search-tag');
                recentSearchTags.forEach(tag => {
                    tag.addEventListener('click', function() {
                        searchInput.value = this.textContent;
                        performSearch(this.textContent);
                    });
                });
            }
        });
        
        searchInput.addEventListener('input', function() {
            performSearch(this.value);
        });
        
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                performSearch(this.value);
            }
        });
    }
    
    // Search button click
    if (searchBtn) {
        searchBtn.addEventListener('click', function() {
            performSearch(searchInput.value);
        });
    }
    
    // Voice search functionality
    if (voiceSearchBtn && 'webkitSpeechRecognition' in window) {
        const recognition = new webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';
        
        voiceSearchBtn.addEventListener('click', function() {
            recognition.start();
            voiceSearchBtn.classList.add('listening');
            voiceSearchBtn.innerHTML = '<i class="fas fa-microphone-alt"></i>';
        });
        
        recognition.onresult = function(event) {
            const transcript = event.results[0][0].transcript;
            searchInput.value = transcript;
            performSearch(transcript);
            voiceSearchBtn.classList.remove('listening');
            voiceSearchBtn.innerHTML = '<i class="fas fa-microphone"></i>';
        };
        
        recognition.onerror = function() {
            voiceSearchBtn.classList.remove('listening');
            voiceSearchBtn.innerHTML = '<i class="fas fa-microphone"></i>';
        };
        
        recognition.onend = function() {
            voiceSearchBtn.classList.remove('listening');
            voiceSearchBtn.innerHTML = '<i class="fas fa-microphone"></i>';
        };
    } else if (voiceSearchBtn) {
        voiceSearchBtn.style.display = 'none';
    }
    
    // Category filter functionality
    searchCategories.forEach(category => {
        category.addEventListener('click', function(e) {
            e.preventDefault();
            const categoryName = this.textContent.toLowerCase();
            searchInput.value = categoryName;
            performSearch(categoryName);
        });
    });
    
    // Close search results when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.search-container')) {
            searchResults.classList.remove('active');
        }
    });
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initEnhancedSearch();
});
