// Cart functionality
let cart = [];
let wishlist = [];
let currentUser = null;

// Show notification
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// Login functionality
function login(email, password) {
    // In a real application, this would be an API call
    // For demo purposes, we'll use a simple check
    if (email === 'admin@example.com' && password === 'admin123') {
        currentUser = {
            email: email,
            name: 'Admin User'
        };
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        showNotification('Login successful!', 'success');
        return true;
    } else {
        showNotification('Invalid email or password', 'error');
        return false;
    }
}

// Logout functionality
function logout() {
    currentUser = null;
    localStorage.removeItem('currentUser');
    showNotification('Logged out successfully', 'success');
}

// Check if user is logged in
function isLoggedIn() {
    return currentUser !== null;
}

// Initialize user session
function initializeUserSession() {
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
        currentUser = JSON.parse(storedUser);
    }
}

// Add to cart
function addToCart(productId) {
    if (!isLoggedIn()) {
        showNotification('Please login to add items to cart', 'error');
        return;
    }

    const product = products.find(p => p.id === productId);
    if (product) {
        cart.push(product);
        updateCartCount();
        showNotification('Product added to cart');
    }
}

// Update cart count
function updateCartCount() {
    const cartCount = document.getElementById('cart-count');
    if (cartCount) {
        cartCount.textContent = cart.length;
    }
}

// Add to wishlist
function addToWishlist(productId) {
    if (!isLoggedIn()) {
        showNotification('Please login to add items to wishlist', 'error');
        return;
    }

    const product = products.find(p => p.id === productId);
    if (product) {
        wishlist.push(product);
        showNotification('Product added to wishlist');
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    initializeUserSession();
    updateCartCount();

    // Add event listeners for login form if it exists
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            if (login(email, password)) {
                window.location.href = 'index.html';
            }
        });
    }

    // Add event listener for logout button if it exists
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            logout();
            window.location.href = 'index.html';
        });
    }
});