require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const connectDB = require('./config/db');
const User = require('./models/userModel');
const productRoutes = require('./routes/productRoutes');
const categoryRoutes = require('./routes/categoryRoutes');
const colorRoutes = require('./routes/colorRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// Connect to database
connectDB();

app.use(cors());
app.use(bodyParser.json());

// Routes
app.use('/api/products', productRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/colors', colorRoutes);
const products = [
    {
        id: 1,
        category: 'Paint Brushes',
        name: 'Professional Round Brush',
        price: 12.99,
        image: '/images/round-brush.jpg',
        description: 'High-quality round brush for detailed work'
    },
    {
        id: 2,
        category: 'Paint Brushes',
        name: 'Flat Brush Set',
        price: 24.99,
        image: '/images/flat-brush-set.jpg',
        description: 'Set of 5 flat brushes for various applications'
    },
    {
        id: 3,
        category: 'Interior Paint',
        name: 'Premium Wall Paint',
        price: 29.99,
        image: '/images/interior-paint.jpg',
        description: 'High-quality interior wall paint'
    }
];

// Auth routes
app.post('/api/register', async (req, res) => {
    try {
        const { username, email, password } = req.body;

        const userExists = await User.findOne({ email });
        if (userExists) {
            return res.status(400).json({ message: 'User already exists' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const user = await User.create({
            username,
            email,
            password: hashedPassword
        });

        if (user) {
            const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, {
                expiresIn: '30d'
            });

            res.status(201).json({
                _id: user._id,
                username: user.username,
                email: user.email,
                isAdmin: user.isAdmin,
                token
            });
        }
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

app.post('/api/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await User.findOne({ email });

        if (user && (await bcrypt.compare(password, user.password))) {
            const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, {
                expiresIn: '30d'
            });

            res.json({
                _id: user._id,
                username: user.username,
                email: user.email,
                isAdmin: user.isAdmin,
                token
            });
        } else {
            res.status(401).json({ message: 'Invalid email or password' });
        }
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
    const user = users.find(u => u.username === username);
    if (!user) return res.status(400).json({ message: 'User not found' });
    
    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) return res.status(400).json({ message: 'Invalid password' });
    
    const token = jwt.sign({ username }, 'your_jwt_secret');
    res.json({ token });
});

// Product routes
app.get('/api/products', (req, res) => {
    res.json(products);
});

app.get('/api/products/category/:category', (req, res) => {
    const { category } = req.params;
    const filteredProducts = products.filter(p => p.category === category);
    res.json(filteredProducts);
});

// Cart routes
let carts = {};

app.post('/api/cart', (req, res) => {
    const { userId, productId, quantity } = req.body;
    if (!carts[userId]) carts[userId] = [];
    
    const existingItem = carts[userId].find(item => item.productId === productId);
    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        carts[userId].push({ productId, quantity });
    }
    
    res.json(carts[userId]);
});

app.get('/api/cart/:userId', (req, res) => {
    const { userId } = req.params;
    res.json(carts[userId] || []);
});

// Payment route (mock)
app.post('/api/payment', (req, res) => {
    const { amount, cardDetails } = req.body;
    // In production, integrate with a real payment gateway
    res.json({ success: true, message: 'Payment processed successfully' });
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
