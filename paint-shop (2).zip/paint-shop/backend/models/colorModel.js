const mongoose = require('mongoose');

const colorSchema = mongoose.Schema({
    name: {
        type: String,
        required: true,
        unique: true
    },
    hexCode: {
        type: String,
        required: true,
        unique: true
    }
}, {
    timestamps: true
});

const Color = mongoose.model('Color', colorSchema);
module.exports = Color;
